

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center
                                        justify-content-between">
                    <h4 class="mb-sm-0 font-size-18">Shipments</h4>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">

            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-start">
                            <h4 class="card-title mb-4">Shipments</h4>
                        </div>
                        <div class="float-end"><a
                                href="<?php echo e(route('shipment.create')); ?>"
                                class="btn btn-dark btn-sm">Create New</a></div>
                    </div>
                    <div class="card-body">


                        <div class="table-responsive">
                            <table class="table align-middle table-nowrap mb-0">
                                <thead class="table-light">
                                    <tr>
                                      
                                        <th class="align-middle">
                                             ID</th>
                                        <th class="align-middle">
                                            Store Name</th>
                                        <th class="align-middle">
                                            Date</th>
                                        <th class="align-middle">
                                            Address</th>
                                        <th class="align-middle">
                                            Tracking ID</th>
                                        <th class="align-middle">
                                            Status</th>
                                        <th class="align-middle">
                                            View Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ship; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   
                                    <tr>
                                       
                                       <td><a href="javascript: void(0);"
                                               class="text-body fw-bold"> <?php echo e($list->shipid); ?></a>
                                       </td>
                                       <td><?php echo e($list->storename); ?></td>
                                       <td>
                                           <?php echo e($list->datetime); ?>

                                       </td>
                                       <td>
                                       <?php echo e($list->store_address); ?>

                                       </td>
                                       <td>
                                       <?php echo e($list->tracking_number); ?>  
                                       </td>
                                       <td>
                                       <span
                                               class="badge badge-pill
                                                                   badge-soft-success
                                                                   font-size-11">Paid</span>
                                       </td>
                                       <td>
                                           <!-- Button trigger modal -->
                                           <button type="button"
                                               class="btn btn-primary btn-sm
                                                                   btn-rounded waves-effect
                                                                   waves-light"
                                               data-bs-toggle="modal"
                                               data-bs-target=".transaction-detailModal">
                                               View Details
                                           </button>
                                       </td>
                                   </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    

                                                       </tbody>
                            </table>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <!-- end row -->
        </div>
    <!-- container-fluid -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\cargo\visitor\resources\views/shipment/index.blade.php ENDPATH**/ ?>