<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ShipmentsController extends Controller
{
    //
}
